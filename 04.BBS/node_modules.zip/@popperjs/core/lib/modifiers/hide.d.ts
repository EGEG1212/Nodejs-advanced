import { Modifier } from "../types";
export declare type HideModifier = Modifier<"hide", {}>;
declare const _default: Modifier<"hide", {}>;
export default _default;
