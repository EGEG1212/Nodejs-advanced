define( [
	"./fnToString"
], function( fnToString ) {
	"use strict";

	return fnToString.call( Object );
} );
